import tensorflow as tf
import numpy as np
from tensorflow.examples.tutorials.mnist import input_data


with tf.Session() as sess:
    saver = tf.train.import_meta_graph('model.ckpt.meta')
    saver.restore(sess, 'model.ckpt')

    variables = tf.global_variables()
    Ws = [var for var in variables if len(var.get_shape()) == 2]
    Bs = [var for var in variables if len(var.get_shape()) == 1]
    assert(len(Ws) == len(Bs))
    x_tf = sess.graph.get_tensor_by_name('x:0')
    y_tf = sess.graph.get_tensor_by_name('y:0')

    nonlinearities = [tf.identity for i in range(len(Ws) - 1)] + [tf.nn.softmax]
    out = x_tf
    for W, b, nonlinearity in zip(Ws, Bs, nonlinearities):
        out = nonlinearity(tf.nn.xw_plus_b(out, weights=W, biases=b))

    correct_tf = tf.cast(tf.equal(tf.cast(tf.argmax(out, -1), tf.int32), y_tf), tf.int32)

    test = input_data.read_data_sets("/tmp", False).test
    correct = sess.run(correct_tf, feed_dict={x_tf: test.images,
                                              y_tf: test.labels})

    print("Accuracy: {}".format(np.mean(correct)))
